<?php

namespace App\Controllers;
use App\Models\Liste_etudiant;

class Lister extends BaseController
{
    
    public function index()
    {
	//$session = \Config\Services::session();
	//$user = $session->get('UserConnecter');
	//$user ="A";
	//if(isset($user)){
        	return redirect()->to('Lister/Etudiant');
	//}
	//else{
	//	return redirect()->to('/connexion');
	//}
    }

    public function Etudiant()
    {
        $list = new Liste_etudiant();
        $reponse['tout'] = $list->List("");
        $reponse['statut'] = $list->List("");
        $reponse['date'] = date("Y-m-d");	
        $reponse['niv'] = "";
        $reponse['username'] = "";
	$reponse['affaire'] = "";

        return view('Liste',$reponse);
    }

    public function search()
    {
        // Charger la bibliothèque de session
        helper(['session']);

        $grade = $this->request->getVar('grade');
        $cherche = $this->request->getVar('nom');
        $statut = $this->request->getVar('statut');
        $list = new Liste_etudiant();

        /// Tester si on cherche à une date précise
        $dateTrie = "";
        if (session()->has('date')){
            $dateTrie = session()->get('date');
        }

        $reponse = $list->List($dateTrie);

        $retour = [];
        $tab = [];
        $data = [];
        $niveau = "";
        $recherche = "";
        $position = "";

        if($grade=="Restaurer"){
            $grade = "";
            $cherche = "";
            $statut = "";
            session()->set('date', "");
        }

        // Avoir les données dans les variables de session dont nom si il y eu recherche, grade et le statut
        // tout ceci est par rapport au recherche effectué par l'utilisateur
        $niveau = $this->getData('grade', $grade);
        $recherche = $this->getData('nom', $cherche);
        $position =  $this->getData('statut', $statut);

        $recherche = trim($recherche);
        $recherche = preg_replace('/ +/',' ',$recherche);

        /// Triage pour avoir le resultat final de liste
        $retour = $this->triage($reponse, 'nom', $recherche);
        $tab = $this->triage($retour, 'grade', $niveau);
        $data = $this->triage($tab, 'id', $position);

        if(empty($dateTrie)){
            $dateTrie = date("Y-m-d");
        }

        $bd = array(
            'tout' => $tab,
            'statut' => $data,
	    'date' => $dateTrie,
	    'niv' => $niveau,
            'username' => $recherche,
            'affaire' => $position,
        );

        return view('Liste', $bd);
    }

    public function getData($cle, $compare){
        $valeur="";
        if (session()->has($cle)) {
            $valeur = session()->get($cle);
            if($compare !== NULL){
                if($valeur !== $compare){
                    session()->set($cle, $compare);
                    $valeur = session()->get($cle);
                }
            }
            
        } else {
            session()->set($cle, $compare);
            $valeur = $compare;
        }
        return $valeur;
    }

    public function triage($tableau, $cle, $recherche){
	    $tab = [];
	    $vide = [];
        foreach($tableau as $row){
            $val= strstr(strtolower($row[$cle]),strtolower($recherche));      
            if(!empty($val)){
                $tab[] = $row;
            }
	}

	if(empty($tab)){
            $nbr = 0;
            foreach($tableau as $row){
               $nbr = $row['total'];               
            }
            $tab[] = [
                'total' => $nbr,
                'nom' => "",
                'grade' => "",
                'id' => ""
            ];
        }

        return $tab;
    }

    public function Trier(){
        helper(['session']);

        $tri = $this->request->getVar('date');

        $list = new Liste_etudiant();
       // $reponse= $list->List($tri);

        $date = $this->getData('date', $tri);
    
        $reponse['tout'] = $list->List($date);
        $reponse['statut'] = $list->List($date);

        if(empty($date)){
            $date = date("Y-m-d");
        }

        $reponse['date'] = $date;
	$reponse['niv'] = "";
        $reponse['username'] = "";
	$reponse['affaire'] = "";


        return view('Liste',$reponse); 
    }
}
