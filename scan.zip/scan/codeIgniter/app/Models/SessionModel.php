<?php

class SessionModel extends Model {
  protected $table = 'session_actives';
  protected $allowedFields = ['id_session', ];
  
}

