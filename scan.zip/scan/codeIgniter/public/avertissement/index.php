<?php
session_start();

// // Définir le cookie 'seenWarning' si ce n'est pas déjà fait
// if (!isset($_COOKIE['seenWarning'])) {
//     //setcookie('seenWarning', 'true', time() + 86400, "/", ".votresite.com"); // Expire dans 1 jour
//     setcookie('seenWarning', 'true', time() + 86400, "/", ".");
//     echo "<h1>NON DEFINIE</h1>";
// }
// else{
//     echo "<h1>DEFINIE</h1>";
// }


// Vérifier si l'utilisateur a déjà vu l'avertissement
if (!isset($_SESSION['seenWarning'])) {
    $_SESSION['seenWarning'] = true;
} else {
    // Rediriger vers la page sécurisée si l'avertissement a déjà été vu
    header('Location: https://qrcode.mit');
    //exit();
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guide de sécurité pour accéder à notre site</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Guide de sécurité pour accéder à notre site</h1>
    </header>
    <main>
        <section>
            <h2>Introduction :</h2>
            <p>Bienvenue sur notre site web ! Nous sommes ravis de vous avoir parmi nous. Si vous rencontrez actuellement un avertissement de sécurité lors de l'accès à notre site, ne vous inquiétez pas, nous sommes là pour vous aider à résoudre ce problème.</p>
        </section>
        <section>
            <h2>Pourquoi cet avertissement s'affiche-t-il ?</h2>
            <p>L'avertissement "Votre connexion n'est pas privée" ou similaire peut apparaître comme le certificat SSL/TLS de notre site est auto-signé ou a expiré. Cela signifie que votre navigateur considère notre site comme non sécurisé.Mais il n'y a rien de grave, vous pouvez faire confiance à notre site.</p>
        </section>
        <section>
            <h2>Comment accéder à notre site en toute sécurité :</h2>
            <ul>
                <li><strong>Étapes:</strong></li>
                <li><strong>1.</strong> Aller vers 'Paramètres avancés'</li>
                <li><strong>2.</strong> Puis le lien en dessous : 'Continuer vers le site dev.qrcode.mit'</li>
                <br>
                <li><strong>Google Chrome :</strong> Suivez les instructions pour contourner l'avertissement dans Chrome.</li>
                <li><strong>Mozilla Firefox :</strong> Suivez les instructions pour contourner l'avertissement dans Firefox.</li>
                <li><strong>Microsoft Edge :</strong> Suivez les instructions pour contourner l'avertissement dans Edge.</li>
                <li><strong>Safari :</strong> Suivez les instructions pour contourner l'avertissement dans Safari.</li>
            </ul>
        </section>
        <section>
            <h2>Accéder à notre site sécurisé</h2>
            <p>Pour accéder à notre site sécurisé, cliquez sur le lien suivant :</p>
            <p><a href="https://qrcode.mit">Accéder à la version sécurisée</a></p>
        </section>
        <section>
            <h2>Utilisation de la Caméra pour le Scan</h2>
            <p>Pour effectuer un scan avec notre application, il est nécessaire d'<em><b>autoriser l'accès à votre caméra</b></em>. Cela permet à l'application d'interagir directement avec votre appareil photo pour capturer des images.</p>
            <p>Il est important de noter que si vous bloquez l'accès à votre caméra, vous pourriez ne plus être capable de réaliser des scans avec notre application.</p>
            <p>Assurez-vous donc d'autoriser l'accès à votre caméra chaque fois que vous souhaitez effectuer un scan.</p>
        </section>
        <section>
            <h2>Contactez-nous :</h2>
            <p>Si vous rencontrez toujours des problèmes pour accéder à notre site en toute sécurité, n'hésitez pas à nous contacter à <a href="mailto:fnomenjanahary@mit-ua.mit?cc=mfock@mit-ua.mg,mlenepveu@mit-ua.mg,trakotosoa@mit-ua.mg">qrcode@mit-ua.mg</a>. Nous sommes là pour vous aider !</p>
        </section>
    </main>
    <footer>
        <p>Merci de votre compréhension et de votre soutien continu.</p>
    </footer>
</body>
</html>

